
!pip install scanpy scipy umap-learn leidenalg
!pip install infercnvpy
!pip install hmmlearn
!pip install pykalman
